

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class chromebrowser {

 public static void main(String[] args) {
	 
  System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe"); //consumo driver google chrome
  
  WebDriver driver = new ChromeDriver();   //uso interface webdriver con chrome driver
  driver.get("http://www.google.com"); 
  WebElement element = driver.findElement(By.name("q")); //uso objeto  web element para encontrar el id de la caja de busqueda en la direccion seteada y lo igualo
  element.sendKeys("AccentureBootCamp!");   // le aplico un texto para enviarselo
  element.submit();  //envio la informacion para aplicar la busqueda 
  
  if(element.isDisplayed())   // si el cuadro de la busqueda de google que con herramienta inspeccionar elemento sabemos se llama "q" esta presente se podra aplicar la busqueda del submit en ese caso se efectuaria la busqueda
  {
	System.out.println("Prueba de busqueda en Caja de Texto superada");
  }
  else
  {
	  System.out.println("prueba no superada");
  }
  
 // driver.close();  // para poder ver visual la ejecucion de busqueda deshabilito esta linea , de lo contrario ejecuta rapido y cierra chrome
 }
}